package com.onyetech.onyetech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnyetechApplicationTests {

    @Test
    void contextLoads() {
    }

}
