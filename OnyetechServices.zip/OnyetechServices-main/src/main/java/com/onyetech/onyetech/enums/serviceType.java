package com.onyetech.onyetech.enums;

public enum serviceType {
    WEBDESIGN,
    CONSULTANCY,
    DIGITAL_MARKETING

}
