package com.onyetech.onyetech.enums;

public enum UserRole {
    USER,
    ADMIN
}
