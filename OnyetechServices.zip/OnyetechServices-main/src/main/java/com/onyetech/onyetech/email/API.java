package com.onyetech.onyetech.email;

public class API {
    public static String API_KEY = "2139501c86750f76ed274ab3401c13f5";
    public static String API_SECRET = "75f8b77492d60e11da19be467e6c9149";
}
