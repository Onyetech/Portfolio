package com.onyetech.onyetech.enums;

public enum TransactionStatus {
    PENDING , FAILED , SUCCESSFUL
}
